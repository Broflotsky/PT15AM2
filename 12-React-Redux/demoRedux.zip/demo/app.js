import React from 'react';
import { render } from 'react-dom';
import Counter from './src/components/Counter.jsx';

render(
    <div>
      <Counter />
      <Counter />
      <Counter />
      <Counter />
      <Counter />
      <Counter />
      <Counter />
      <Counter />
      <Counter />
    </div>,
  document.getElementById('app')
);
