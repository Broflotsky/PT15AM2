import React, { Component } from 'react';
import store from '../store.js';
import { increment, decrement, reset } from '../actions';

class Counter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      counter: store.getState().count,
    }
  }
  componentDidMount() {
    this.unsuscribe = store.subscribe(() => {
      this.setState({
        counter: store.getState().count,
      });
    });
  }
  componentWillUnmount() {
    this.unsuscribe();
  }
  onIncrement() {
    store.dispatch(increment());
  }
  onDecrement() {
    store.dispatch(decrement());
  }
  onReset() {
    store.dispatch(reset());
  }
  render() {
    return (
      <p>
        Clicked: {this.state.counter} times
        {' '}
        <button onClick={this.onIncrement}>
          +
        </button>
        {' '}
        <button onClick={this.onDecrement}>
          -
        </button>
        {' '}
        <button onClick={this.onReset}>
          Reset
        </button>

      </p>
    )
  }
}
export default Counter;
