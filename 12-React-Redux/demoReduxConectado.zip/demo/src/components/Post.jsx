import React from 'react';
import store from '../store.js';
import * as actionsCreators from '../actions';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

class Post extends React.Component {
  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
  }
  onClick(e) {
    e.preventDefault();
    const value = document.querySelector('input').value;
    this.props.fetchPost(value);
  }
  render () {
    return <div>
      <input name='id' />
      <button onClick={this.onClick} >
        get
      </button>
      <div>
        {this.props.loading ? 'loading...' : (this.props.post && this.props.post.title)}
      </div>
    </div>
  }
}

function mapStateToProps(state) {
  return {
    loading: state.loading,
    post: state.post,
  }
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators(actionsCreators, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Post);